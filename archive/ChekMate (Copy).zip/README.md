
  # ChekMate (Copy)

  This is a code bundle for ChekMate (Copy). The original project is available at https://www.figma.com/design/i3I4Bp3BmkJDy56PpOeW2G/ChekMate--Copy-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  